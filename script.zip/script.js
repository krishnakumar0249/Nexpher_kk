const scroll = new LocomotiveScroll({
    el: document.querySelector('#main'),
    smooth: true
});



gsap.from("#banner-text ,#banner-text2 h1",{
    y:100,
    opacity:0,
    delay:0.5,
    duration:0.9,
    stagger:0.3
})



gsap.from("#main-img img",{
    //y:100,
    scale:0.8,
    opacity:0,
    delay:1.5,
    duration:0.9,

})