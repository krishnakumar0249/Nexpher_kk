


const scroll = new LocomotiveScroll({
    el: document.querySelector('#main'),
    smooth: true,
    
});


    gsap.from(".nav > .nav-list> li:hover",{
        x:100,
        opacity:0,
        delay:1.5,
        duration:2.9,
        stagger:0.3 
    })
    

gsap.from(".nav > .nav-header > .nav-title img",{
    x:100,
    opacity:0,
    delay:1.5,
    duration:2.9,
    stagger:0.3 
})

gsap.from(".nav > .nav-list i",{
    y:100,
    opacity:0,
    delay:1.5,
    duration:2.9,
    stagger:0.3
})


gsap.from("#banner-text ,#banner-text2 h1",{
    y:100,
    opacity:0,
    delay:0.5,
    duration:0.9,
    stagger:0.3
})



gsap.from("#main-img img",{
    //y:100,
    scale:0.8,
    opacity:0,
    delay:1.5,
    duration:0.9,

})





gsap.from("#banner-text img",{
    y:100,
    scale:0.8,
    delay:1.5,
    duration:2.0,

})


gsap.from("#banner-text2 img",{
    x:-100,
    scale:0.8,
    delay:1.5,
    duration:3.0,

})

///PAge3
var tl = gsap.timeline({scrollTrigger:{
    trigger:"#top",
  markers:true,
    start:"30% 50%",
    end:"100% 50%",
    scrub:2, 
    var:true
}})

tl
.to("#top",{
    top:"-50%"
},'a')
.to("#bottom",{
    bottom:"-50%"
},'a')
.to("#top-h",{
    top:"80%"
},'a')
.to("#bottom-h",{
    bottom:"-80%"
},'a')
.to("content",{
    marginTop:"0%"
},'a')


document.addEventListener("mousemove")


// PAge2
    // var swiper = new Swiper('.swiper-container', {
    //   direction: 'vertical',
    //   spaceBetween: 30,
    //   centeredSlides: true,
    //   autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    //   },
    //   pagination: {
    //     el: '.swiper-pagination',
    //     clickable: true,
    //   },
    //   navigation: {
    //     nextEl: '.swiper-button-next',
    //     prevEl: '.swiper-button-prev',
    //   },
    // });




/////PAge 4






